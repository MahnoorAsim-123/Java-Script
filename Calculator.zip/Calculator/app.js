//Greet User
alert("Welcome to the piday.\nYou can solve here your basic calculations!");

// Geting input on display screen
function input(num){
    // getting input
    var displayScreen = document.getElementById("displayScreen");
    // +=   --> we used this bcz we don't wanna reassign the value but concatenate with the previous one.
    // previous value rahe or upcoming value concatenate hoti rahe.
    displayScreen.value += num;
}



// function for all clear button
function clearScreen(){
    // getting input
    var displayScreen = document.getElementById("displayScreen");
    // empty string is used for clear the screen
    displayScreen.value = "";
}

//  function for clear button
function clearstep(){
    // getting input
    var displayScreen = document.getElementById("displayScreen");
    // slice(0,-1) is used for clear last value
    displayScreen.value = displayScreen.value.slice(0,-1);
}


//function for getting results | performed calculations using eval()
function results(){
    // getting input
    var displayScreen = document.getElementById("displayScreen");
    displayScreen.value = eval(displayScreen.value);
}


