// Q1
function showAlert(){
    alert("Thank You!");
}
function showNeg(){
    alert("Oops! We will try our best next time.");
}
function showDef(){
    alert("Natural Language Processing");
}


//Q2
function order(){
    alert("Added into the cart.")
}


//Q3
function deleteBtn1(){
    var delBtn = document.getElementsByTagName("tr");
    console.log(delBtn)
    delBtn[0].className = "delete"; 
}
function deleteBtn2(){
    var delBtn = document.getElementsByTagName("tr");
    console.log(delBtn)
    delBtn[1].className = "delete"; 
}
function deleteBtn3(){
    var delBtn = document.getElementsByTagName("tr");
    console.log(delBtn)
    delBtn[2].className = "delete";  
}


//Q4
function turnOn(img){
    var a = document.getElementById("bulb");
    a.src = "./assets/on.png";
    a.style.cursor ="pointer";
}
function turnOff(img){
    var a = document.getElementById("bulb");
    a.src = "./assets/off.png";
}


//Q5
var clicks = 0;
function counter(){
    clicks += 1;
    document.getElementById("clicks").innerHTML = clicks;
    }
function counterDec(){
        clicks -= 1;
        document.getElementById("clicks").innerHTML = clicks;
        }

// E V E N T S 
// PART2

// Q1
function formSubmit(){
    var fname = document.getElementById("fname");
    var lname = document.getElementById("lname");
    var email = document.getElementById("email");
    var  pass = document.getElementById("pass");
    var cpass = document.getElementById("cpass");

    fname.value = fname.value;
    lname.value = lname.value;
    email.value = email.value;
    pass.value = pass.value;
    cpass.value = cpass.value;

    document.write("FIRST NAME: "+ fname.value + "<br/>")
    
    document.write("LAST NAME: "+ lname.value + "<br/>")
    
    document.write("EMAIL: "+ email.value + "<br/>")
    
    document.write("PASSWORD: "+ pass.value + "<br/>")
    
    document.write("CONFIRM PASSWORD: "+ cpass.value)
}

// Q2
function readMore(){
    var para = document.getElementById("para");
    var showPara = document.getElementById("hide");
    para.innerHTML += showPara.innerHTML;
}
