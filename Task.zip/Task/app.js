// Q1

function setBackgroundColour(){
    var a = prompt("Which colour theme do you want to apply on a background?");
    var b = document.getElementById("bgClr");
    b.style.backgroundColor = a;   
}
function setFontColour(){
    var a = prompt("Which colour of text do you want see?");
    var b = document.getElementById("bgClr");
    b.style.color = a;   
}
function setFontStyle(){
    var a = prompt("Which font style do you want to apply?","eg: italic.....");
    var b = document.getElementById("bgClr");
    b.style.fontStyle = a;   
}
function setFontSize(){
    var a = prompt("Which font style do you want to apply?", "eg: 24px....");
    var b = document.getElementById("bgClr");
    b.style.fontSize = a;
}


//Q2

function big(){
    var a = document.getElementById("img");
    a.className = "bigImg";
}
function small(){
    var a = document.getElementById("img");
    a.className = "smallImg";
}
function hide(){
    var a = document.getElementById("img");
    a.className = "hideImg";
}
function show(){
    var a = document.getElementById("img");
    a.className = "showImg";
}



//Q3
function turnOn(img){
    var a = document.getElementById("bulb");
    a.src = "./assets/on.png";
    a.style.cursor ="pointer";
}
function turnOff(img){
    var a = document.getElementById("bulb");
    a.src = "./assets/off.png";
}



//Q4
function changeClr(){
    var a = prompt("Choose Colour For Paragraph 1");
    var b = prompt("Choose Colour For Paragraph 2");
    var c = prompt("Choose Colour For Paragraph 3");
    var d = prompt("Choose Colour For Paragraph 4");
    var e = document.getElementsByTagName("p");
    e[0].style.color = a;
    e[1].style.color = b;
    e[2].style.color = c;
    e[3].style.color = d;   
}


//Q4
function cClr(){
    var a = prompt("Choose Colour For Paragraph 1");
    var b = prompt("Choose Colour For Paragraph 2");
    var c = document.getElementsByTagName("p");
    c[0].style.color = a;
    c[3].style.color = b;   
}
