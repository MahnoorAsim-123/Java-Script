//     FUNCTIONS -----  Assignment # 35-38

/*Write a function that displays current date & time in your
browser.*/
// function date() {
//     let date = new Date();
//     document.write(date);
// }
// invoke a function
// date(); 


/*Write a function that takes first & last name and then it
greets the user using his full name.*/
// function greet(){
//     let firstName = prompt("Enter your First Name:");
//     let lastName  = prompt("Enter your Last Name:");
//     alert("Welcome "+firstName +" " +lastName);
// }
// greet();


/*Write a function that adds two numbers (input by user)
and returns the sum of two numbers.*/
// function sum(){
//     const num1 = +prompt("Enter Number 1");
//     const num2 = +prompt("Enter Number 2");
//     return "Sum of " +num1 +" + " +num2 +" is " +(num1 + num2)
// }
//  console.log(sum()) 


/*Write a function that takes three arguments num1, num2
& operator & compute the desired operation. Return and
show the desired result in your browser.*/
// function calculator(num1 , num2 , operator){
//     if(operator === "/"){
//         alert(num1 / num2);
//     }
//     else if(operator === "*"){
//         alert(num1 * num2);
//     }
//     else if(operator === "+"){
//         alert(num1 + num2);
//     }
//     else if(operator === "-"){
//         alert(num1 - num2);
//     }
//     else{
//         alert("Choose right operator");
//     }
// }
// var num1 = +prompt("Enter Number 1");
// var num2 = +prompt("Enter Number 2");
// var operator = prompt("Choose any one operator -->  /,*,+,-");
// calculator(num1,num2,operator);   


/* Write a function that squares its argument.*/
// function squareNum(base,exponent){
//     var a = Math.pow(base,exponent);
//     console.log(a)
// }
// var base = +prompt("Enter base");
// var exponent = +prompt("Enter exponent");
// squareNum(base,exponent);


/*Write a function that computes factorial of a number.*/
// function factorialNumber(num){
//     var fact = 1;
//     if(num === 0 || num === 1){
//         console.log(fact);
//     }
//     else{ 
//         for (i = 1; i <= num; i++) {
//         fact =  fact * i;
//     }
//     console.log(fact);
// }
// }
// var num = +prompt("Enter any number");
// factorialNumber(num);


/*Write a function that take start and end number as inputs
& display counting in your browser.*/
// function counting(startValue , endValue){
// for(var i = startValue; i <= endValue; i++){
//     console.log(i);
// }
// }
// var startValue = +prompt("Enter initial value to start counting");
// var endValue   = +prompt("Enter last value to end counting");
// counting(startValue , endValue);


/*Write a nested function that computes hypotenuse of a right angle triangle.
Hypotenuse2 = Base2 + Perpendicular2
Take base and perpendicular as inputs. 
Outer function : calculateHypotenuse()
Inner function: calculateSquare()*/
// function hypotenuse(a, b) {
//     function square(x){
//          return x*x; 
//         }
//     return Math.sqrt(square(a) + square(b));
//  }
//  function secondFunction() {
//     var result;
//     result = hypotenuse(1,2);
//     document.write ( result );
//  }


// Write a function that calculates the area of a rectangle.
// A = width * height
// Pass width and height in following manner:
// i. Arguments as value
// ii. Arguments as variables
// function myFun(w , h){
//   var  area = w * h;
//   console.log(area);
// }
// myFun(10 , 5);


// Write a JavaScript function that checks whether a passed
// string is palindrome or not?
// A palindrome is word, phrase, or sequence that reads the same backward as
// forward, e.g., madam.
// function Palindrome(string) {
//     const len = string.length;
//     // loop through half of the string
//     for (let i = 0; i < len / 2; i++) {
//         //check first and last character is same or not
//         if (string[i] !== string[len - 1 - i]) {
//             return 'It is not a palindrome';
//         }
//     }
//     return 'It is a palindrome';
// }
// const string = prompt('Enter a string: ');
// const value = Palindrome(string);
// console.log(value);


// Write a JavaScript function that accepts a string as a
// parameter and converts the first letter of each word of the
// string in upper case.
// EXAMPLE STRING : 'the quick brown fox'
// EXPECTED OUTPUT : 'The Quick Brown Fox'
// function uppercase(str)
// {
//   var array1 = str.split(' ');
//   var newarray1 = [];
    
//   for(var x = 0; x < array1.length; x++){
//       newarray1.push(array1[x].charAt(0).toUpperCase()+array1[x].slice(1));
//   }
//   return newarray1.join(' ');
// }
// console.log(uppercase("the quick brown fox"));


// Write a JavaScript function that accepts a string as a
// parameter and find the longest word within the string.
// EXAMPLE STRING : 'Web Development Tutorial'
// EXPECTED OUTPUT : 'Development'


// Write a JavaScript function that accepts two arguments, a
// string and a letter and the function will count the number of 
// occurrences of the specified letter within the string.
// Sample arguments : 'JSResourceS.com', 'o'



// Create 2 functions that calculate properties of a circle, using
// the definitions here.
// Create a function called calcCircumference:
// • Pass the radius to the function.
// • Calculate the circumference based on the radius, and output
// "The circumference is NN".
// Create a function called calcArea:
// • Pass the radius to the function.
// • Calculate the area based on the radius, and output "The area
// is NN".
// Circumference of circle = 2πr
// Area of circle = πr2